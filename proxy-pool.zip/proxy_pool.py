# -*- coding: utf-8 -*-
"""
Proxy Pool - 最终完整生产版
支持：多源、真实测试、多出口自动+主动更换、Web管理、持久化、告警、限速、Prometheus、YAML配置
"""

import os
import sys
import socket
import threading
import time
import random
import logging
import json
import struct
import signal
import select
import base64
import hashlib
from html import escape as html_escape
import urllib.request
import urllib.error
from urllib.parse import urlparse, parse_qs, unquote
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import List, Dict, Optional, Tuple
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn
from datetime import datetime, timedelta
from collections import defaultdict
from pathlib import Path

# ====================== 加载 .env ======================
def load_dotenv(path: str = ".env") -> None:
    """读取同目录 .env（systemd 会通过 EnvironmentFile 注入；此函数让手动运行也生效）。
    已存在的真实环境变量优先，不被 .env 覆盖。"""
    p = Path(path)
    if not p.exists():
        return
    try:
        content = p.read_text(encoding="utf-8")
        for line in content.splitlines():
            line = line.rstrip('\r\n')
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, _, v = line.partition("=")
            k = k.strip()
            v = v.strip().strip('"').strip("'")
            if k and k not in os.environ:
                os.environ[k] = v
    except Exception as e:
        print(f"[Config] 加载 .env 失败: {e}")

load_dotenv()

# ====================== 尝试加载 YAML 配置 ======================
def load_config():
    cfg = {}
    config_file = Path("config.yaml")
    if config_file.exists():
        try:
            import yaml
            with open(config_file, "r", encoding="utf-8") as f:
                cfg = yaml.safe_load(f) or {}
            print("[Config] 已加载 config.yaml")
        except Exception as e:
            print(f"[Config] 加载 config.yaml 失败: {e}")
    return cfg

YAML_CFG = load_config()

def conf(key, default=None):
    """优先级：环境变量 > config.yaml > 默认值"""
    env_val = os.environ.get(key.upper())
    if env_val is not None:
        return env_val
    return YAML_CFG.get(key, default)

# ====================== 配置 ======================
CONFIG = {
    "countries": [c.strip().upper() for c in str(conf("countries", "JP,US,KR,SG,TW,HK,DE,GB,NL,TH,PH")).split(",") if c.strip()],
    "sources": conf("sources", {
        "proxifly_http":   "https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/protocols/http/data.json",
        "proxifly_socks5": "https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/protocols/socks5/data.json",
        "syndrid":         "https://proxy.syndrid.com/api/v2/proxies?limit=250",
        "cmahmud_http":    "https://raw.githubusercontent.com/cmahmud/proxies/main/alive/http.txt",
        "cmahmud_https":   "https://raw.githubusercontent.com/cmahmud/proxies/main/alive/https.txt",
        "cmahmud_socks5":  "https://raw.githubusercontent.com/cmahmud/proxies/main/alive/socks5.txt",
        "cmahmud_gold":    "https://raw.githubusercontent.com/cmahmud/proxies/main/gold/all.txt",
        # daily_free_vpn：从订阅里抽取可用的 socks/http 节点（其余协议仅用于导出订阅）
        "daily_free_vpn":  "https://raw.githubusercontent.com/cbusifabcap/daily_free_vpn/refs/heads/main/Z.txt",
    # ================= 新增订阅源：GitHub Proxy-List 类源 =================
    "themiralay_list":     "https://raw.githubusercontent.com/themiralay/Proxy-List-World/master/data.txt",
    "ship_happens_bro":    "https://raw.githubusercontent.com/ShipHappensBro/Proxy-list/main/proxies.txt",
    "vpslab_list":         "https://raw.githubusercontent.com/VPSLabCloud/VPSLab-Free-Proxy-List/main/http_all.txt",
    "solispirit_http":     "https://raw.githubusercontent.com/SoliSpirit/proxy-list/main/http.txt",
    "solispirit_https":    "https://raw.githubusercontent.com/SoliSpirit/proxy-list/main/https.txt",
    "solispirit_socks4":   "https://raw.githubusercontent.com/SoliSpirit/proxy-list/main/socks4.txt",
    "solispirit_socks5":   "https://raw.githubusercontent.com/SoliSpirit/proxy-list/main/socks5.txt",
    }),
    "subscriptions": conf("subscriptions", {
        "daily_free_vpn":      "https://raw.githubusercontent.com/cbusifabcap/daily_free_vpn/refs/heads/main/Z.txt",
        "daily_free_vpn_uri":  "https://raw.githubusercontent.com/cbusifabcap/daily_free_vpn/refs/heads/main/sub/URI.yml",
        "daily_free_vpn_clash": "https://raw.githubusercontent.com/cbusifabcap/daily_free_vpn/refs/heads/main/sub/Clash.yml",
    }),
    "test_url": conf("test_url", "http://httpbin.org/ip"),
    "test_timeout": int(conf("test_timeout", 8)),
    "max_workers": int(conf("max_workers", 50)),
    "max_candidates_per_source": int(conf("max_candidates_per_source", 3000)),
    "min_good_proxies": int(conf("min_good_proxies", 30)),
    "refresh_interval": int(conf("refresh_interval", 600)),
    "max_fail_count": int(conf("max_fail_count", 3)),
    "cool_down_minutes": int(conf("cool_down_minutes", 30)),
    "bind_host": conf("bind_host", "0.0.0.0"),
    "local_http_port": int(conf("local_http_port", 8080)),
    "local_socks_port": int(conf("local_socks_port", 1080)),
    "web_port": int(conf("web_port", 8888)),
    "multi_exit_count": int(conf("multi_exit_count", 8)),
    "multi_exit_base": int(conf("multi_exit_base", 18081)),
    "auth_user": conf("auth_user", "admin"),
    "auth_pass": conf("auth_pass", "proxy123"),
    "max_connections": int(conf("max_connections", 500)),
    "log_file": conf("log_file", "proxy_pool.log"),
    "multi_fail_threshold": int(conf("multi_fail_threshold", 2)),
    "multi_health_interval": int(conf("multi_health_interval", 120)),
    # 健康检查：连续失败 N 次才更换，避免单次抖动造成频繁换上游
    "health_check_url": conf("health_check_url", conf("test_url", "http://httpbin.org/ip")),
    "health_check_timeout": int(conf("health_check_timeout", 6)),
    "health_check_retries": int(conf("health_check_retries", 2)),
    "health_check_fail_threshold": int(conf("health_check_fail_threshold", 3)),
    "lock_file": conf("lock_file", "proxy_pool.lock"),
    "persist_file": conf("persist_file", "good_proxies.json"),
    "persist_min_success": int(conf("persist_min_success", 3)),
    "alert_webhook": conf("alert_webhook", ""),
    "alert_threshold": int(conf("alert_threshold", 5)),
    "rate_limit_per_ip": int(conf("rate_limit_per_ip", 30)),
    "enable_geoip": str(conf("enable_geoip", "false")).lower() == "true",
}

# ====================== 日志 ======================
log = logging.getLogger("ProxyPool")
log.setLevel(logging.INFO)
fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s", "%Y-%m-%d %H:%M:%S")
ch = logging.StreamHandler(sys.stdout)
ch.setFormatter(fmt)
log.addHandler(ch)
fh = logging.FileHandler(CONFIG["log_file"], encoding="utf-8")
fh.setFormatter(fmt)
log.addHandler(fh)

# ====================== 限速 ======================
ip_conn_count = defaultdict(int)
ip_lock = threading.Lock()

def check_rate_limit(ip: str) -> bool:
    with ip_lock:
        if ip_conn_count[ip] >= CONFIG["rate_limit_per_ip"]:
            return False
        ip_conn_count[ip] += 1
        return True

def release_rate(ip: str):
    with ip_lock:
        ip_conn_count[ip] = max(0, ip_conn_count[ip] - 1)

def rate_limit_cleaner():
    while not shutdown_event.is_set():
        shutdown_event.wait(60)
        if shutdown_event.is_set():
            break
        with ip_lock:
            ip_conn_count.clear()

# ====================== 数据结构 ======================
class Proxy:
    def __init__(self, protocol: str, ip: str, port: int, country: str = "XX"):
        self.protocol = protocol.lower()
        self.ip = ip
        self.port = int(port)
        self.country = (country or "XX").upper()
        self.fail_count = 0
        self.cool_until: Optional[datetime] = None
        self.latency = 9999
        self.last_ok = 0.0
        self.success_count = 0

    @property
    def available(self) -> bool:
        if self.cool_until and datetime.now() < self.cool_until:
            return False
        return self.fail_count < CONFIG["max_fail_count"]

    def mark_fail(self):
        self.fail_count += 1
        if self.fail_count >= CONFIG["max_fail_count"]:
            self.cool_until = datetime.now() + timedelta(minutes=CONFIG["cool_down_minutes"])
            log.warning(f"进入冷却: {self}")

    def mark_ok(self, latency: int = 0):
        self.fail_count = 0
        self.cool_until = None
        self.last_ok = time.time()
        self.success_count += 1
        if latency > 0:
            # 用指数滑动平均平滑延迟，避免单次慢响应拉高整体延迟
            self.latency = int(self.latency * 0.6 + latency * 0.4) if self.latency < 9999 else latency

    def __str__(self):
        return f"{self.protocol}://{self.ip}:{self.port}[{self.country}]"

    def to_dict(self):
        return {
            "protocol": self.protocol, "ip": self.ip, "port": self.port,
            "country": self.country, "fail": self.fail_count,
            "available": self.available, "latency": self.latency,
            "success": self.success_count
        }

    def to_persist(self):
        return {"protocol": self.protocol, "ip": self.ip, "port": self.port,
                "country": self.country, "success": self.success_count, "latency": self.latency,
                "fail": self.fail_count,
                "cool_until": self.cool_until.isoformat() if self.cool_until else None}

class ProxyPool:
    def __init__(self):
        self.proxies: List[Proxy] = []
        self.lock = threading.RLock()
        self.multi: Dict[int, Proxy] = {}
        self.active_connections = 0
        self.conn_lock = threading.Lock()
        self.last_alert = 0

    def update(self, lst: List[Proxy]):
        with self.lock:
            # 合并策略：本次刷新测试通过的代理 + 旧池中本次未测试到的代理（保留兜底）
            # 如果旧代理本次被测试到了，则用新结果替换；未测试到的旧代理保留。
            tested_keys = {(p.protocol, p.ip, p.port) for p in lst}
            merged = []
            seen = set()
            for p in lst:
                key = (p.protocol, p.ip, p.port)
                if key in seen:
                    continue
                seen.add(key)
                merged.append(p)
            # 保留旧池中未参与本轮测试的代理
            for p in self.proxies:
                key = (p.protocol, p.ip, p.port)
                if key not in tested_keys and key not in seen:
                    seen.add(key)
                    merged.append(p)
            # 最终只保留仍然可用的
            self.proxies = [p for p in merged if p.available]
            log.info(f"代理池更新完成 | 可用: {len(self.proxies)}")
            self._check_alert()

    def get(self, country: Optional[str] = None) -> Optional[Proxy]:
        with self.lock:
            if country:
                c = country.upper()
                av = [p for p in self.proxies if p.available and (p.country or "").upper() == c]
                if not av:
                    # 该国家无可用代理时退回不限国家
                    av = [p for p in self.proxies if p.available]
            else:
                av = [p for p in self.proxies if p.available]
            if not av:
                return None
            # 延迟越低、成功次数越高 → 权重越大；无需排序，O(n) 一次扫描
            weights = [
                (1.0 / (1 + (p.latency or 9999) / 500.0)) * (1 + min(p.success_count or 0, 50) / 20.0)
                for p in av
            ]
            return random.choices(av, weights=weights, k=1)[0]

    def get_many(self, n: int, country: Optional[str] = None) -> List[Proxy]:
        with self.lock:
            if country:
                c = country.upper()
                av = [p for p in self.proxies if p.available and (p.country or "").upper() == c]
                if not av:
                    av = [p for p in self.proxies if p.available]
            else:
                av = [p for p in self.proxies if p.available]
            av.sort(key=lambda x: x.latency)
            return av[:n]
    def cool(self, p: Proxy):
        with self.lock:
            p.mark_fail()
    def acquire_conn(self) -> bool:
        with self.conn_lock:
            if self.active_connections >= CONFIG["max_connections"]:
                return False
            self.active_connections += 1
            return True

    def release_conn(self):
        with self.conn_lock:
            self.active_connections = max(0, self.active_connections - 1)

    def stats(self) -> dict:
        with self.lock:
            total = len(self.proxies)
            av = sum(1 for p in self.proxies if p.available)
            return {
                "total": total, "available": av, "cooling": total - av,
                "active_conn": self.active_connections,
                "multi": {str(k): str(v) for k, v in self.multi.items()},
                "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }

    def _check_alert(self):
        av = sum(1 for p in self.proxies if p.available)
        if av < CONFIG["alert_threshold"] and time.time() - self.last_alert > 300:
            self.last_alert = time.time()
            send_alert(f"⚠️ ProxyPool 告警：当前可用代理仅 {av} 个（阈值 {CONFIG['alert_threshold']}）")

pool = ProxyPool()

# ====================== 多出口状态 ======================
multi_exit_state = {}
multi_exit_lock = threading.Lock()

# ====================== 运行控制 ======================
shutdown_event = threading.Event()
refresh_lock = threading.Lock()

# ====================== 多出口监听器管理 ======================
multi_listeners = {}
multi_listeners_lock = threading.Lock()

# ====================== 核心服务状态（供 /health 探活） ======================
service_status = {"socks": False, "http": False, "web": False}

# ====================== 单实例锁 ======================
_instance_lock_fh = None

def acquire_instance_lock(timeout: float = 15) -> bool:
    """用 flock 保证同一时间只有一个实例；旧实例退出后新实例才能继续（最多等待 timeout 秒）"""
    global _instance_lock_fh
    try:
        import fcntl
    except ImportError:
        return True  # 非 Unix 平台（如 Windows 调试）不加锁
    path = Path(CONFIG.get("lock_file", "proxy_pool.lock"))
    deadline = time.time() + timeout
    try:
        fh = open(path, "a+")
    except Exception as e:
        log.warning(f"无法创建实例锁文件 {path}: {e}")
        return True
    while True:
        try:
            fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            if time.time() >= deadline:
                fh.close()
                return False
            time.sleep(0.5)
            continue
        try:
            fh.seek(0)
            fh.truncate()
            fh.write(str(os.getpid()))
            fh.flush()
        except Exception:
            pass
        _instance_lock_fh = fh
        return True

def replace_multi_exit(port: int, reason: str = "", country: Optional[str] = None,
                       exclude: Optional[Proxy] = None) -> bool:
    with multi_exit_lock:
        # country 显式传入时覆盖偏好；None 表示沿用；""/ALL/全部/XX 表示清除偏好
        if country is None:
            country = (multi_exit_state.get(port) or {}).get("country")
        else:
            c = str(country).strip().upper()
            if c in ("", "ALL", "全部", "XX", "NONE"):
                country = None
            else:
                country = c
        old = multi_exit_state.get(port, {}).get("proxy")
        skip = exclude or old
        # 避开当前失效节点，多试几次拿到不同的代理
        new_proxy = None
        for _ in range(8):
            cand = pool.get(country=country)
            if not cand:
                break
            if skip and cand.ip == skip.ip and cand.port == skip.port:
                continue
            new_proxy = cand
            break
        if new_proxy is None:
            # 同国家没有其他节点时，退回不限国家
            if country:
                for _ in range(8):
                    cand = pool.get(country=None)
                    if not cand:
                        break
                    if skip and cand.ip == skip.ip and cand.port == skip.port:
                        continue
                    new_proxy = cand
                    break
                if new_proxy is not None:
                    log.warning(f"多出口 {port} 国家 {country} 无其他可用节点，改用不限国家节点")
                    country = None
        if new_proxy is None:
            log.warning(f"多出口 {port} 更换失败：无可用代理" + (f"（国家 {country}）" if country else ""))
            return False
        state = {"proxy": new_proxy, "fail": 0, "hc_fail": 0, "last_check": time.time()}
        if country:
            state["country"] = country
        multi_exit_state[port] = state
        pool.multi[port] = new_proxy
        if old:
            log.info(f"多出口 {port} 切换: {old} → {new_proxy} ({reason})")
        else:
            log.info(f"多出口 {port} 初始化: {new_proxy}")
        return True

def bind_multi_exit(port: int, ip: str, proxy_port: int, protocol: str = "http", country: str = "XX", target_country: Optional[str] = None) -> bool:
    """将指定代理节点绑定为某个多出口端口的上游；target_country 为该端口后续自动更换时的国家偏好"""
    try:
        proxy = Proxy(protocol, ip, int(proxy_port), country)
    except Exception:
        return False
    pref = (target_country or country or "").upper()
    if pref in ("", "XX", "ALL", "全部"):
        pref = None
    with multi_exit_lock:
        old = multi_exit_state.get(port, {}).get("proxy")
        state = {"proxy": proxy, "fail": 0, "hc_fail": 0, "last_check": time.time()}
        if pref:
            state["country"] = pref
        multi_exit_state[port] = state
        pool.multi[port] = proxy
    with pool.lock:
        if not any(p.ip == ip and p.port == int(proxy_port) for p in pool.proxies):
            pool.proxies.append(proxy)
    log.info(f"多出口 {port} 绑定: {old} → {proxy} (Web手动绑定" + (f", 国家偏好 {pref}" if pref else "") + ")")
    return True

# ====================== 告警 ======================
def send_alert(msg: str):
    webhook = CONFIG["alert_webhook"]
    if not webhook:
        log.warning(f"[告警] {msg}")
        return
    try:
        data = json.dumps({"text": msg}).encode()
        req = urllib.request.Request(webhook, data=data, headers={"Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=8)
        log.info(f"告警已发送: {msg}")
    except Exception as e:
        log.error(f"告警发送失败: {e}")

# ====================== 持久化 ======================
def load_persisted() -> List[Proxy]:
    path = Path(CONFIG["persist_file"])
    if not path.exists():
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        res = []
        for d in data:
            p = Proxy(d["protocol"], d["ip"], d["port"], d.get("country", "XX"))
            p.success_count = d.get("success", 0)
            p.latency = d.get("latency", 9999)
            p.fail_count = d.get("fail", 0)
            cool_until = d.get("cool_until")
            if cool_until:
                try:
                    p.cool_until = datetime.fromisoformat(cool_until)
                except ValueError:
                    p.cool_until = None
            res.append(p)
        log.info(f"加载持久化优质代理: {len(res)} 个")
        return res
    except Exception as e:
        log.error(f"加载持久化失败: {e}")
        return []

def save_persisted():
    with pool.lock:
        # 保存所有曾成功过且未被判定为永久失效的代理：
        # - 当前可用  → 正常保存
        # - 冷却中    → 保留（fail_count/cool_until 一起存，重启后仍在冷却期内则继续冷却）
        # 不再要求 available=True，避免每次刷新都重新测试导致池子被反复筛选、越来越小
        good = [
            p for p in pool.proxies
            if p.success_count >= CONFIG["persist_min_success"]
        ]
        good.sort(key=lambda x: (-x.success_count, x.latency))
        data = [p.to_persist() for p in good[:200]]
    try:
        with open(CONFIG["persist_file"], "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        log.info(f"已持久化优质代理: {len(data)} 个")
    except Exception as e:
        log.error(f"持久化失败: {e}")

# ====================== 拉取与测试 ======================
def fetch_source(url: str, proto_hint: str = "http") -> List[Proxy]:
    res = []
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "ProxyPool/2.0"})
        with urllib.request.urlopen(req, timeout=15) as r:
            content = r.read().decode("utf-8", errors="ignore").strip()

        if content.startswith("{") or content.startswith("["):
            data = json.loads(content)
            items = data.get("proxies", data) if isinstance(data, dict) else data
            if not isinstance(items, list):
                items = []
            for it in items:
                country = (it.get("as_country") or (it.get("geolocation") or {}).get("country")
                           or it.get("country") or "XX")
                if CONFIG["countries"] and country not in CONFIG["countries"]:
                    continue
                ip = it.get("host") or it.get("ip")
                port = it.get("port")
                proto = (it.get("protocol") or proto_hint).lower()
                if proto == "https":
                    proto = "http"
                if ip and port:
                    res.append(Proxy(proto, ip, int(port), country))
        else:
            country = "XX"
            if CONFIG["countries"] and country not in CONFIG["countries"]:
                return res
            for line in content.splitlines():
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                proto = proto_hint
                target = line
                # 解析代理 URI（socks:// / http(s):// / ...://user:pass@host:port）
                if "://" in line:
                    try:
                        u = urlparse(line)
                        scheme = (u.scheme or proto_hint).lower()
                        if scheme == "https":
                            scheme = "http"
                        host = u.hostname
                        port = u.port
                        if host and port:
                            if scheme in ("http", "socks", "socks4", "socks5"):
                                res.append(Proxy(scheme, host, port, country))
                            else:
                                                            continue
                    except Exception:
                        pass
                    # 回退：剥掉 scheme 后按 ip:port 解析（仅当 scheme 可用时）
                    try:
                        proto, target = line.split("://", 1)
                        proto = proto.lower()
                        if proto == "https":
                            proto = "http"
                        if proto not in ("http", "socks", "socks4", "socks5"):
                            continue
                    except ValueError:
                        continue
                if ":" not in target:
                    continue
                # 去掉 userinfo / 路径 / 查询
                hostpart = target.split("@")[-1]
                hostpart = hostpart.split("/")[0].split("?")[0]
                if ":" not in hostpart:
                    continue
                ip, port_str = hostpart.rsplit(":", 1)
                ip = ip.strip().strip("[]")
                try:
                    res.append(Proxy(proto, ip, int(port_str), country))
                except ValueError:
                    continue
    except Exception as e:
        log.error(f"拉取失败 {url[:50]}... : {e}")
    limit = CONFIG.get("max_candidates_per_source", 3000)
    if len(res) > limit:
        random.shuffle(res)
        res = res[:limit]
        log.info(f"源 {url[:40]}... 候选过多，截断为 {limit}")
    return res

def fetch_all() -> List[Proxy]:
    allp = load_persisted()
    for name, url in CONFIG["sources"].items():
        hint = "socks5" if "socks5" in name else "http"
        ps = fetch_source(url, hint)
        log.info(f"源 {name}: {len(ps)} 个")
        allp.extend(ps)

    seen = set()
    uniq = []
    for p in allp:
        key = (p.ip, p.port)
        if key not in seen:
            seen.add(key)
            uniq.append(p)
    log.info(f"去重后候选: {len(uniq)}")
    return uniq

def sample_candidates(candidates: List[Proxy]) -> List[Proxy]:
    """分层抽样：按源规模分层，避免大源完全吞没小源。
    - 持久化代理优先保留
    - 其他按协议类型分层：每个源按占比配额抽样，保证多源均衡"""
    persisted = [p for p in candidates if p.success_count >= CONFIG["persist_min_success"]]
    rest = [p for p in candidates if p.success_count < CONFIG["persist_min_success"]]
    if len(rest) <= 800:
        return candidates
    random.shuffle(rest)
    return persisted + rest[:800]

# ====================== 订阅源透传（daily_free_vpn 等） ======================
_sub_cache: Dict[str, Tuple[str, float]] = {}
_sub_cache_lock = threading.Lock()
SUB_CACHE_TTL = 1800  # 30 分钟

def fetch_subscription(name: str) -> Tuple[Optional[str], str]:
    """拉取并缓存订阅内容，返回 (内容, content_type)。失败返回 (None, err)。"""
    subs = CONFIG.get("subscriptions") or {}
    url = subs.get(name)
    if not url:
        return None, "未知订阅"
    now = time.time()
    with _sub_cache_lock:
        cached = _sub_cache.get(name)
        if cached and now - cached[1] < SUB_CACHE_TTL:
            return cached[0], "text/plain; charset=utf-8"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "ProxyPool/2.0"})
        with urllib.request.urlopen(req, timeout=20) as r:
            raw = r.read()
            ctype = r.headers.get("Content-Type", "text/plain; charset=utf-8")
        text = raw.decode("utf-8", errors="replace")
        with _sub_cache_lock:
            _sub_cache[name] = (text, now)
        return text, ctype
    except Exception as e:
        log.warning(f"拉取订阅 {name} 失败: {e}")
        with _sub_cache_lock:
            cached = _sub_cache.get(name)
            if cached:
                return cached[0], "text/plain; charset=utf-8"
        return None, str(e)

def probe_proxy(p: Proxy, url: str = None, timeout: float = None) -> Tuple[bool, str]:
    """通过代理真实请求一次，返回 (是否可用, 失败原因)。不修改代理状态。"""
    url = url or CONFIG["test_url"]
    timeout = timeout or CONFIG["test_timeout"]
    u = urlparse(url)
    host = u.hostname or "httpbin.org"
    port = u.port or (443 if u.scheme == "https" else 80)
    path = (u.path or "/") + (("?" + u.query) if u.query else "")
    try:
        if p.protocol.startswith("socks"):
            import socks
            s = socks.socksocket()
            try:
                s.set_proxy(socks.SOCKS5, p.ip, p.port)
                s.settimeout(timeout)
                s.connect((host, port))
                req = (f"GET {path} HTTP/1.1\r\nHost: {host}\r\n"
                       f"User-Agent: ProxyPool/2.0\r\nConnection: close\r\n\r\n")
                s.sendall(req.encode())
                data = b""
                while True:
                    chunk = s.recv(4096)
                    if not chunk:
                        break
                    data += chunk
                    if len(data) > 8192:
                        break
            finally:
                try: s.close()
                except Exception: pass
            if not data:
                return False, "空响应(SOCKS5)"
            line = data.split(b"\r\n", 1)[0].decode("latin-1", errors="ignore")
            if " 2" not in line and " 3" not in line:
                return False, f"状态异常 {line[:60]}"
            return True, ""
        else:
            handler = urllib.request.ProxyHandler({
                "http": f"http://{p.ip}:{p.port}",
                "https": f"http://{p.ip}:{p.port}",
            })
            opener = urllib.request.build_opener(handler)
            opener.addheaders = [("User-Agent", "ProxyPool/2.0")]
            with opener.open(url, timeout=timeout) as resp:
                if resp.status >= 400:
                    return False, f"HTTP {resp.status}"
            return True, ""
    except Exception as e:
        msg = str(e).strip() or e.__class__.__name__
        return False, msg[:120]

def test_proxy(p: Proxy, log_fail: bool = False, mark: bool = True) -> bool:
    if shutdown_event.is_set():
        return False
    start = time.time()
    ok, err = probe_proxy(p)
    if ok:
        if mark:
            p.mark_ok(int((time.time() - start) * 1000))
        return True
    if mark:
        p.mark_fail()
    if log_fail:
        log.warning(f"代理测试失败 {p}: {err}")
    return False

def refresh():
    if shutdown_event.is_set():
        return
    if not refresh_lock.acquire(blocking=False):
        log.info("刷新已在进行中，跳过本次")
        return
    try:
        log.info(">>> 开始刷新代理池")
        candidates = fetch_all()
        if not candidates:
            log.warning("无候选代理")
            return

        # 防止内存爆掉：最多测试 800 个（可按机器内存调整）
        candidates = sample_candidates(candidates)
        if len(candidates) > 800:
            candidates = candidates[:800]
            log.info(f"候选过多，按分层抽样后保留 800 个进行测试")

        good = []
        try:
            with ThreadPoolExecutor(max_workers=CONFIG["max_workers"]) as ex:
                fmap = {}
                for p in candidates:
                    if shutdown_event.is_set():
                        break
                    try:
                        fmap[ex.submit(test_proxy, p)] = p
                    except RuntimeError:
                        # interpreter shutting down
                        break
                # 已有目标可用数量（默认 30）后提前停止，避免测试大量无效代理
                target_good = CONFIG.get("min_good_proxies", 30)
                for fut in as_completed(fmap):
                    if shutdown_event.is_set():
                        break
                    p = fmap[fut]
                    try:
                        if fut.result():
                            good.append(p)
                            if len(good) >= target_good:
                                break
                    except Exception:
                        pass
        except RuntimeError:
            log.warning("刷新线程池已关闭，终止本次刷新")
            return
        if shutdown_event.is_set():
            log.info("收到退出信号，放弃本次刷新结果")
            return
        good.sort(key=lambda x: x.latency)
        pool.update(good)
        save_persisted()
        log.info(f">>> 刷新完成 | 可用 {len(good)} / 候选 {len(candidates)}")
    except Exception as e:
        log.exception(f"刷新异常: {e}")
    finally:
        refresh_lock.release()

# ====================== 多出口主动健康检查 ======================
def multi_health_check():
    interval = CONFIG["multi_health_interval"]
    url = CONFIG["health_check_url"]
    timeout = CONFIG["health_check_timeout"]
    retries = max(1, CONFIG["health_check_retries"])
    threshold = max(1, CONFIG["health_check_fail_threshold"])
    while not shutdown_event.is_set():
        shutdown_event.wait(interval)
        if shutdown_event.is_set():
            break
        with multi_exit_lock:
            ports = list(multi_exit_state.keys())
        for port in ports:
            if shutdown_event.is_set():
                break
            with multi_exit_lock:
                state = multi_exit_state.get(port)
                if not state:
                    continue
                proxy = state["proxy"]
                pref = state.get("country")
            # 真实 HTTP 请求验证；瞬时抖动重试
            ok = False
            last_err = ""
            for attempt in range(retries):
                ok, last_err = probe_proxy(proxy, url, timeout)
                if ok or shutdown_event.is_set():
                    break
                if attempt + 1 < retries:
                    time.sleep(1)
            if ok:
                proxy.mark_ok()
                with multi_exit_lock:
                    if port in multi_exit_state:
                        multi_exit_state[port]["hc_fail"] = 0
                continue
            # 记录连续失败次数，未达阈值只记日志不换（避免抢同一个坏节点反复切换）
            with multi_exit_lock:
                if port not in multi_exit_state:
                    continue
                hc_fail = int(multi_exit_state[port].get("hc_fail", 0)) + 1
                multi_exit_state[port]["hc_fail"] = hc_fail
            if hc_fail < threshold:
                log.warning(f"多出口 {port} 健康检查失败 {hc_fail}/{threshold}: {last_err}")
                continue
            log.warning(f"多出口 {port} 连续 {hc_fail} 次健康检查失败（{last_err}），更换上游")
            proxy.mark_fail()
            replace_multi_exit(port, f"连续{hc_fail}次健康检查失败", country=pref, exclude=proxy)

# ====================== 转发核心 ======================
def forward(a: socket.socket, b: socket.socket):
    try:
        while True:
            r, _, _ = select.select([a, b], [], [], 90)
            if not r:
                break
            for s in r:
                data = s.recv(8192)
                if not data:
                    return
                (b if s is a else a).sendall(data)
    except Exception:
        pass
    finally:
        for s in (a, b):
            try: s.close()
            except: pass

def check_auth(header: Optional[str]) -> bool:
    if not CONFIG["auth_user"]:
        return True
    if not header or not header.startswith("Basic "):
        return False
    try:
        u, p = base64.b64decode(header[6:]).decode().split(":", 1)
        return u == CONFIG["auth_user"] and p == CONFIG["auth_pass"]
    except:
        return False

def web_session_token() -> str:
    raw = f"{CONFIG['auth_user']}:{CONFIG['auth_pass']}:proxy-pool"
    return hashlib.sha256(raw.encode()).hexdigest()

def web_is_authed(handler) -> bool:
    if not CONFIG["auth_user"]:
        # 未配置账号时也不跳过认证，直接视为未登录
        return False
    cookie = handler.headers.get("Cookie", "")
    for part in cookie.split(";"):
        part = part.strip()
        if part.startswith("pp_session="):
            return part[len("pp_session="):] == web_session_token()
    return False

# ====================== SOCKS5 处理 ======================
def _socks5_handshake(client: socket.socket) -> Optional[Tuple[str, int]]:
    data = client.recv(256)
    if not data or data[0] != 5:
        return None
    if CONFIG["auth_user"]:
        client.sendall(b"\x05\x02")
        auth = client.recv(512)
        if len(auth) < 3 or auth[0] != 1:
            return None
        ulen = auth[1]
        user = auth[2:2+ulen].decode()
        plen = auth[2+ulen]
        passwd = auth[3+ulen:3+ulen+plen].decode()
        if user != CONFIG["auth_user"] or passwd != CONFIG["auth_pass"]:
            client.sendall(b"\x01\x01")
            return None
        client.sendall(b"\x01\x00")
    else:
        client.sendall(b"\x05\x00")

    data = client.recv(4)
    if len(data) < 4 or data[1] != 1:
        return None
    atyp = data[3]
    if atyp == 1:
        addr = socket.inet_ntoa(client.recv(4))
        port = struct.unpack("!H", client.recv(2))[0]
    elif atyp == 3:
        length = client.recv(1)[0]
        addr = client.recv(length).decode()
        port = struct.unpack("!H", client.recv(2))[0]
    else:
        client.sendall(b"\x05\x08\x00\x01\x00\x00\x00\x00\x00\x00")
        return None
    return addr, port

def connect_upstream(upstream: Proxy, addr: str, port: int):
    if upstream.protocol.startswith("socks"):
        import socks
        remote = socks.socksocket()
        remote.set_proxy(socks.SOCKS5, upstream.ip, upstream.port)
        remote.settimeout(12)
        remote.connect((addr, port))
    else:
        remote = socket.create_connection((upstream.ip, upstream.port), 12)
        remote.sendall(f"CONNECT {addr}:{port} HTTP/1.1\r\nHost: {addr}:{port}\r\n\r\n".encode())
        if b"200" not in remote.recv(4096):
            raise Exception("CONNECT failed")
    return remote

def handle_socks5(client: socket.socket, upstream: Proxy, client_ip: str = ""):
    if not pool.acquire_conn():
        client.close()
        return
    try:
        target = _socks5_handshake(client)
        if not target:
            return
        addr, port = target
        remote = connect_upstream(upstream, addr, port)
        client.sendall(b"\x05\x00\x00\x01\x00\x00\x00\x00\x00\x00")
        forward(client, remote)
        upstream.mark_ok()
    except Exception as e:
        log.debug(f"SOCKS5失败 {upstream}: {e}")
        pool.cool(upstream)
    finally:
        pool.release_conn()
        if client_ip:
            release_rate(client_ip)
        try: client.close()
        except: pass

def handle_socks5_multi(client: socket.socket, port: int, client_ip: str = ""):
    if not pool.acquire_conn():
        client.close()
        return
    upstream = None
    with multi_exit_lock:
        state = multi_exit_state.get(port)
        if state:
            upstream = state["proxy"]
    if not upstream or not upstream.available:
        pref = (multi_exit_state.get(port) or {}).get("country")
        if not replace_multi_exit(port, "当前不可用", country=pref):
            client.close()
            pool.release_conn()
            if client_ip: release_rate(client_ip)
            return
        with multi_exit_lock:
            upstream = multi_exit_state[port]["proxy"]
    try:
        target = _socks5_handshake(client)
        if not target:
            return
        addr, port_dst = target
        remote = connect_upstream(upstream, addr, port_dst)
        client.sendall(b"\x05\x00\x00\x01\x00\x00\x00\x00\x00\x00")
        forward(client, remote)
        upstream.mark_ok()
        with multi_exit_lock:
            if port in multi_exit_state:
                multi_exit_state[port]["fail"] = 0
            multi_exit_state.setdefault(port, {"fail": 0})["hc_fail"] = 0
    except Exception as e:
        log.debug(f"多出口 {port} 失败 ({upstream}): {e}")
        with pool.lock:
            upstream.mark_fail()
        with multi_exit_lock:
            if port in multi_exit_state:
                multi_exit_state[port]["fail"] = int(multi_exit_state[port].get("fail", 0)) + 1
                fail_cnt = multi_exit_state[port]["fail"]
            else:
                fail_cnt = CONFIG["multi_fail_threshold"]
        if fail_cnt >= CONFIG["multi_fail_threshold"]:
            pref = (multi_exit_state.get(port) or {}).get("country")
            replace_multi_exit(port, f"连续失败{fail_cnt}次", country=pref, exclude=upstream)
    finally:
        pool.release_conn()
        if client_ip: release_rate(client_ip)
        try: client.close()
        except: pass

# ====================== HTTP 代理 ======================
class HTTPProxyHandler(BaseHTTPRequestHandler):
    def do_CONNECT(self):
        client_ip = self.client_address[0]
        if not check_rate_limit(client_ip):
            self.send_error(429, "Rate limit exceeded")
            return
        if CONFIG["auth_user"] and not check_auth(self.headers.get("Proxy-Authorization")):
            self.send_response(407)
            self.send_header("Proxy-Authenticate", 'Basic realm="Proxy"')
            self.end_headers()
            release_rate(client_ip)
            return
        if not pool.acquire_conn():
            self.send_error(503, "Too many connections")
            release_rate(client_ip)
            return
        host, _, port = self.path.partition(":")
        port = int(port or 443)
        up = pool.get()
        if not up:
            pool.release_conn()
            release_rate(client_ip)
            self.send_error(502, "No proxy available")
            return
        try:
            remote = connect_upstream(up, host, port)
            self.send_response(200, "Connection Established")
            self.end_headers()
            forward(self.connection, remote)
            up.mark_ok()
        except Exception as e:
            log.debug(f"HTTP失败 {up}: {e}")
            pool.cool(up)
            try: self.send_error(502)
            except: pass
        finally:
            pool.release_conn()
            release_rate(client_ip)

    def log_message(self, *args): pass

# ====================== 服务启动 ======================
def create_socks_socket():
    """同步绑定 SOCKS5 端口；失败直接抛异常，由 main 退出（便于 systemd 拉起）"""
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind((CONFIG["bind_host"], CONFIG["local_socks_port"]))
    sock.settimeout(1.0)
    sock.listen(256)
    return sock

def serve_socks(sock):
    log.info(f"SOCKS5 监听 {CONFIG['bind_host']}:{CONFIG['local_socks_port']}")
    while not shutdown_event.is_set():
        try:
            client, addr = sock.accept()
        except socket.timeout:
            continue
        except Exception as e:
            if shutdown_event.is_set():
                break
            log.error(f"SOCKS5 accept error: {e}")
            continue
        client_ip = addr[0]
        if not check_rate_limit(client_ip):
            client.close()
            continue
        up = pool.get()
        if up:
            threading.Thread(target=handle_socks5, args=(client, up, client_ip), daemon=True).start()
        else:
            release_rate(client_ip)
            client.close()
    try: sock.close()
    except: pass

def create_http_server():
    class T(ThreadingMixIn, HTTPServer):
        daemon_threads = True
        allow_reuse_address = True
    return T((CONFIG["bind_host"], CONFIG["local_http_port"]), HTTPProxyHandler)

def serve_http(srv):
    log.info(f"HTTP  监听 {CONFIG['bind_host']}:{CONFIG['local_http_port']}")
    srv.serve_forever()

def start_multi_listener(port: int):
    """启动某个端口的监听线程（若尚未启动）"""
    with multi_listeners_lock:
        if port in multi_listeners:
            return multi_listeners[port]
        # placeholder
        multi_listeners[port] = None
    def serve(p=port):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind((CONFIG["bind_host"], p))
            s.settimeout(1.0)
            s.listen(64)
        except Exception as e:
            log.error(f"多出口 {p} 绑定失败: {e}")
            with multi_listeners_lock:
                multi_listeners.pop(p, None)
            return
        log.info(f"多出口 {p} 已启动（自动+主动更换）")
        while not shutdown_event.is_set():
            try:
                client, addr = s.accept()
            except socket.timeout:
                continue
            except Exception as e:
                if shutdown_event.is_set():
                    break
                log.error(f"多出口 {p} accept 异常: {e}")
                continue
            client_ip = addr[0]
            if not check_rate_limit(client_ip):
                client.close()
                continue
            threading.Thread(target=handle_socks5_multi, args=(client, p, client_ip), daemon=True).start()
        try:
            s.close()
        except Exception:
            pass
    t = threading.Thread(target=serve, daemon=True, name=f"multi-{port}")
    t.start()
    with multi_listeners_lock:
        multi_listeners[port] = t
    return t

def start_multi():
    ports = list(range(CONFIG["multi_exit_base"], CONFIG["multi_exit_base"] + CONFIG["multi_exit_count"]))
    for port in ports:
        replace_multi_exit(port, "初始化")
    for port in ports:
        start_multi_listener(port)

# ====================== Web + Prometheus ======================
class WebHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        # 登录/登出
        if self.path == "/login":
            if not CONFIG["auth_user"]:
                self._login_page(error="未配置 auth_user/auth_pass，Web 面板已禁用")
            else:
                self._login_page()
            return
        if self.path == "/logout":
            self.send_response(302)
            self.send_header("Set-Cookie", "pp_session=; Path=/; Max-Age=0")
            self.send_header("Location", "/login")
            self.end_headers()
            return
        # 健康检查端点不需要登录，供 systemd/监控探活使用
        if self.path == "/health":
            try:
                st = pool.stats()
            except Exception:
                st = {}
            healthy = all(service_status.values())
            with multi_listeners_lock:
                multi_bound = sorted(p for p, t in multi_listeners.items() if t is not None)
            body = {
                "status": "ok" if healthy else "degraded",
                "available": st.get("available", 0),
                "services": dict(service_status),
                "multi_ports": multi_bound,
                "pid": os.getpid(),
            }
            self._json(body, code=200 if healthy else 503)
            return
        # 订阅源透传（公开，便于 Clash/V2Ray/Sing-box 等客户端直接订阅）
        if self.path.startswith("/sub/"):
            name = self.path[len("/sub/"):].split("?")[0].strip("/")
            if not name:
                self._json({"error": "missing name",
                            "available": list((CONFIG.get("subscriptions") or {}).keys())}, code=400)
                return
            content, ctype = fetch_subscription(name)
            if content is None:
                self.send_error(502, ctype)
                return
            data = content.encode("utf-8", errors="replace")
            self.send_response(200)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "public, max-age=1800")
            self.end_headers()
            self.wfile.write(data)
            return
        if not web_is_authed(self):
            self._redirect("/login")
            return
        if self.path == "/api/stats":
            self._json(pool.stats())
            return
        if self.path == "/api/proxies":
            with pool.lock:
                data = [p.to_dict() for p in sorted(pool.proxies, key=lambda x: x.latency)[:200]]
            self._json(data)
            return
        if self.path == "/refresh":
            if not shutdown_event.is_set():
                threading.Thread(target=refresh, daemon=True).start()
            self._redirect("/")
            return
        if self.path.startswith("/replace/"):
            try:
                part = self.path.split("/")[-1]
                port_str, _, qs = part.partition("?")
                port = int(port_str)
                q = parse_qs(qs) if qs else {}
                pref = (q.get("country") or [None])[0]
                if pref in ("", "ALL", "全部", "XX"):
                    pref = None
                replace_multi_exit(port, "Web手动更换", country=pref)
            except Exception:
                pass
            self._redirect("/")
            return
        if self.path.startswith("/add_multi"):
            try:
                parsed = urlparse(self.path)
                qs = parse_qs(parsed.query)
                pref = (qs.get("country") or [None])[0]
                if pref in ("", "ALL", "全部", "XX"):
                    pref = None
                # 分配新端口
                with multi_listeners_lock:
                    used = set(multi_listeners.keys()) | set(multi_exit_state.keys())
                port = CONFIG["multi_exit_base"] + CONFIG["multi_exit_count"]
                while port in used:
                    port += 1
                # 绑定
                replace_multi_exit(port, "Web添加", country=pref)
                start_multi_listener(port)
            except Exception as e:
                log.error(f"添加多出口失败: {e}")
            self._redirect("/")
            return
        if self.path.startswith("/bind"):
            try:
                parsed = urlparse(self.path)
                qs = parse_qs(parsed.query)
                ip = (qs.get("ip") or [""])[0]
                pport = int((qs.get("port") or ["0"])[0])
                target = int((qs.get("to") or ["0"])[0])
                proto = (qs.get("proto") or ["http"])[0]
                node_country = (qs.get("node_country") or ["XX"])[0]
                pref = (qs.get("pref") or [""])[0]
                if pref in ("", "ALL", "全部", "XX"):
                    pref = None
                if ip and pport and target:
                    bind_multi_exit(target, ip, pport, proto, country=node_country, target_country=pref)
            except Exception as e:
                log.error(f"绑定失败: {e}")
            self._redirect("/")
            return
        if self.path == "/export/clash":
            self._export_clash()
            return
        if self.path == "/metrics":
            self._metrics()
            return



        st = pool.stats()
        country_opts = '<option value="ALL">全部国家</option>' + "".join(f'<option value="{c}">{c}</option>' for c in CONFIG.get("countries", []))
        multi_rows = ""
        for k, v in st.get("multi", {}).items():
            st_country = ""
            try:
                st_country = (multi_exit_state.get(int(k)) or {}).get("country") or ""
            except Exception:
                st_country = (multi_exit_state.get(k) or {}).get("country") or ""
            sel = country_opts.replace(f'value="{st_country}"', f'value="{st_country}" selected') if st_country else country_opts
            multi_rows += f"""<tr>
              <td><span class="badge badge-ok">绑定</span></td>
              <td class="mono">127.0.0.1:{k}</td>
              <td colspan="2" class="muted mono" style="font-size:12px">{v}{'  [' + st_country + ']' if st_country else ''}</td>
              <td>
                <form action="/replace/{k}" method="get" style="display:inline-flex;gap:4px;align-items:center">
                  <select name="country" class="select" style="height:26px;min-width:78px;font-size:11px;padding:0 6px">{sel}</select>
                  <button class="btn btn-sm" type="submit">换上游</button>
                </form>
              </td>
            </tr>"""
        if not multi_rows:
            multi_rows = '<tr><td colspan="5" class="muted">暂无多出口</td></tr>'

        proxy_rows = ""
        multi_ports = list(range(CONFIG["multi_exit_base"], CONFIG["multi_exit_base"] + CONFIG["multi_exit_count"]))
        port_options = "".join(f'<option value="{p}">{p}</option>' for p in multi_ports)
        try:
            items = pool.get_many(80)
        except Exception:
            items = []
        for px in items:
            lat = f"{getattr(px, 'latency_ms', 0) or getattr(px, 'latency', 0)} ms"
            country = getattr(px, "country", None) or "-"
            ptype = (getattr(px, "ptype", None) or getattr(px, "type", None) or getattr(px, "protocol", "http") or "http")
            proto = str(ptype).lower()
            if proto not in ("http", "socks5", "socks4"):
                proto = "http"
            host = getattr(px, "host", None) or getattr(px, "ip", "?")
            port = getattr(px, "port", "?")
            node_country = str(country).upper() if country and country != "-" else "XX"
            pref_opts = country_opts if 'country_opts' in dir() else ('<option value="ALL">全部国家</option>' + "".join(f'<option value="{c}">{c}</option>' for c in CONFIG.get("countries", [])))
            # 默认偏好该节点国家
            if node_country and node_country != "XX":
                pref_opts = pref_opts.replace(f'value="{node_country}"', f'value="{node_country}" selected')
            proxy_rows += f"""<tr>
              <td><span class="badge badge-ok">可用</span></td>
              <td class="mono">{host}:{port}</td>
              <td>{country}</td>
              <td class="muted">{str(ptype).upper()}</td>
              <td class="muted">{lat}</td>
              <td>
                <form action="/bind" method="get" style="display:inline-flex;gap:4px;align-items:center;flex-wrap:wrap">
                  <input type="hidden" name="ip" value="{host}">
                  <input type="hidden" name="port" value="{port}">
                  <input type="hidden" name="proto" value="{proto}">
                  <input type="hidden" name="node_country" value="{node_country}">
                  <select name="to" class="select" style="height:26px;min-width:70px;font-size:11px;padding:0 6px">{port_options}</select>
                  <select name="pref" class="select" style="height:26px;min-width:78px;font-size:11px;padding:0 6px">{pref_opts}</select>
                  <button class="btn btn-sm btn-primary" type="submit">选用</button>
                </form>
              </td>
            </tr>"""
        if not proxy_rows:
            proxy_rows = '<tr><td colspan="6" class="muted">暂无可用代理，请点「更新节点」</td></tr>'

        # 订阅源行
        sub_rows = ""
        for _name, _url in (CONFIG.get("subscriptions") or {}).items():
            sub_rows += f"""<tr><td class="mono">{_name}</td><td class="mono" style="font-size:11px;word-break:break-all"><a href="/sub/{_name}" target="_blank">/sub/{_name}</a>  <span class="muted">({_url})</span></td></tr>"""
        if not sub_rows:
            sub_rows = '<tr><td colspan="2" class="muted">暂无订阅源</td></tr>'
        html = f"""<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Proxy Pool 节点管理系统</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');
:root{{--bg:#0a0e17;--panel:rgba(18,24,40,.75);--border:rgba(255,255,255,.07);--text:#e8edf7;--muted:#8b95a8;--green:#22c55e;--green-bg:rgba(34,197,94,.12);--purple:#6366f1}}
*{{box-sizing:border-box;margin:0;padding:0}}
body{{font-family:Outfit,system-ui,sans-serif;background:var(--bg);background-image:radial-gradient(ellipse at 10% 0%,rgba(99,102,241,.18),transparent 50%),radial-gradient(ellipse at 90% 10%,rgba(34,197,94,.08),transparent 45%);color:var(--text);min-height:100vh}}
header{{display:flex;align-items:center;justify-content:space-between;padding:14px 28px;background:rgba(10,14,23,.85);backdrop-filter:blur(16px);border-bottom:1px solid var(--border);position:sticky;top:0;z-index:50}}
.logo{{display:flex;align-items:center;gap:10px;font-weight:700;font-size:17px}}
.logo-icon{{width:28px;height:28px;border-radius:8px;background:linear-gradient(135deg,#6366f1,#22c55e);display:flex;align-items:center;justify-content:center;font-size:14px}}
.header-actions{{display:flex;gap:10px;align-items:center}}
.btn{{display:inline-flex;align-items:center;gap:6px;height:36px;padding:0 14px;border-radius:10px;border:1px solid var(--border);background:rgba(255,255,255,.04);color:var(--text);font-size:13px;font-weight:600;cursor:pointer;text-decoration:none;transition:.15s}}
.btn:hover{{background:rgba(255,255,255,.08)}}
.btn-green{{background:linear-gradient(135deg,#22c55e,#16a34a);border:none;color:#fff;box-shadow:0 4px 14px rgba(34,197,94,.25)}}
.btn-dark{{background:rgba(255,255,255,.06)}}
.btn-sm{{height:30px;padding:0 10px;font-size:12px;border-radius:8px}}
.btn-primary{{background:linear-gradient(135deg,#6366f1,#4f46e5);border:none;color:#fff}}
.btn-danger{{background:linear-gradient(135deg,#f43f5e,#e11d48);border:none;color:#fff}}
main{{max-width:1200px;margin:0 auto;padding:22px 24px 40px}}
.active-card{{background:linear-gradient(135deg,rgba(99,102,241,.12),rgba(18,24,40,.8));border:1px solid rgba(99,102,241,.25);border-radius:16px;padding:20px 24px;display:flex;justify-content:space-between;align-items:center;gap:20px;margin-bottom:18px;box-shadow:0 8px 32px rgba(99,102,241,.15)}}
.active-left{{display:flex;gap:16px;align-items:flex-start}}
.active-icon{{width:48px;height:48px;border-radius:12px;background:rgba(99,102,241,.2);border:1px solid rgba(99,102,241,.3);display:flex;align-items:center;justify-content:center;font-size:22px}}
.active-title{{display:flex;align-items:center;gap:10px;margin-bottom:6px}}
.active-title .name{{font-size:15px;font-weight:600;color:#a5b4fc}}
.active-ip{{font-size:22px;font-weight:700;font-family:JetBrains Mono,monospace;margin-bottom:8px}}
.active-meta{{display:flex;flex-wrap:wrap;gap:14px;font-size:13px;color:var(--muted)}}
.active-meta strong{{color:var(--text);font-weight:500}}
.filter-bar{{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;background:var(--panel);border:1px solid var(--border);border-radius:14px;padding:12px 16px;margin-bottom:16px}}
.filters{{display:flex;gap:10px;flex-wrap:wrap}}
.select{{height:36px;padding:0 12px;border-radius:10px;background:rgba(255,255,255,.04);border:1px solid var(--border);color:var(--text);font-size:13px;min-width:120px}}
.filter-actions{{display:flex;gap:8px}}
.table-wrap{{background:var(--panel);border:1px solid var(--border);border-radius:14px;overflow:hidden}}
table{{width:100%;border-collapse:collapse}}
th{{text-align:left;padding:12px 14px;font-size:12px;font-weight:600;color:var(--muted);border-bottom:1px solid var(--border);background:rgba(0,0,0,.2)}}
td{{padding:12px 14px;font-size:13px;border-bottom:1px solid var(--border)}}
tr:last-child td{{border-bottom:none}}
tr:hover td{{background:rgba(255,255,255,.02)}}
.mono{{font-family:JetBrains Mono,monospace;font-size:12.5px}}
.muted{{color:var(--muted)}}
.badge{{display:inline-flex;align-items:center;gap:5px;padding:3px 10px;border-radius:20px;font-size:12px;font-weight:600}}
.badge-ok{{background:var(--green-bg);color:var(--green)}}
.badge-ok::before{{content:'';width:6px;height:6px;border-radius:50%;background:var(--green)}}
.badge-conn{{background:rgba(34,197,94,.2);color:#4ade80;border:1px solid rgba(34,197,94,.35)}}
.section-title{{font-size:14px;font-weight:600;color:#a5b4fc;margin:22px 0 12px}}
.stats-mini{{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:18px}}
.stat-card{{background:var(--panel);border:1px solid var(--border);border-radius:12px;padding:14px 16px}}
.stat-card strong{{display:block;font-size:24px;font-weight:700}}
.stat-card span{{font-size:12px;color:var(--muted)}}
@media(max-width:768px){{.stats-mini{{grid-template-columns:repeat(2,1fr)}}.active-card{{flex-direction:column;align-items:stretch}}}}
</style>
</head>
<body>
<header>
  <div class="logo"><div class="logo-icon">⚡</div>Proxy Pool 节点管理系统</div>
  <div class="header-actions">
    <a class="btn btn-dark" href="/" target="_blank">首页</a>
    <a class="btn btn-green" href="/refresh">⟳ 更新节点</a>
    <a class="btn btn-dark" href="/logout">登出</a>
  </div>
</header>
<main>
  <div class="active-card">
    <div class="active-left">
      <div class="active-icon">⚡</div>
      <div>
        <div class="active-title">
          <span class="badge badge-conn">运行中</span>
          <span class="name">本地代理网关</span>
        </div>
        <div class="active-ip">{CONFIG.get('bind_host','0.0.0.0')}:{CONFIG.get('local_http_port',8080)} / :{CONFIG.get('local_socks_port',1080)}</div>
        <div class="active-meta">
          <span>可用: <strong>{st.get('available',0)}</strong></span>
          <span>总计: <strong>{st.get('total',0)}</strong></span>
          <span>冷却: <strong>{st.get('cooling',0)}</strong></span>
          <span>连接: <strong>{st.get('active_conn',0)}</strong></span>
          <span>更新: <strong>{st.get('time','-')}</strong></span>
        </div>
      </div>
    </div>
    <a class="btn btn-danger" href="/refresh">刷新池</a>
  </div>

  <div class="stats-mini">
    <div class="stat-card"><strong>{st.get('total',0)}</strong><span>总代理</span></div>
    <div class="stat-card"><strong style="color:#22c55e">{st.get('available',0)}</strong><span>可用</span></div>
    <div class="stat-card"><strong style="color:#f59e0b">{st.get('cooling',0)}</strong><span>冷却中</span></div>
    <div class="stat-card"><strong>{st.get('active_conn',0)}</strong><span>活跃连接</span></div>
  </div>

  <div class="filter-bar">
    <div class="filters">
      <select class="select"><option>全部节点</option><option>仅可用</option></select>
      <select class="select"><option>所有国家</option><option>JP</option><option>US</option><option>KR</option><option>SG</option></select>
      <select class="select"><option>所有类型</option><option>HTTP</option><option>SOCKS5</option></select>
    </div>
    <div class="filter-actions">
      <a class="btn" href="#multi">🌐 多出口</a>
      <a class="btn" href="/export/clash">导出 Clash</a>
    </div>
  </div>

  <div class="table-wrap">
    <table>
      <thead><tr><th>状态</th><th>IP 地址 : 端口</th><th>国家</th><th>类型</th><th>延迟</th><th>操作</th></tr></thead>
      <tbody>{proxy_rows}</tbody>
    </table>
  </div>

   <div class="section-title" id="multi">🌐 多出口绑定</div>
  <div style="display:flex;gap:8px;align-items:center;margin-bottom:10px;flex-wrap:wrap">
    <form action="/add_multi" method="get" style="display:inline-flex;gap:4px;align-items:center">
      <select name="country" class="select" style="height:30px;min-width:90px;font-size:12px">{country_opts}</select>
      <button class="btn btn-sm btn-green" type="submit">+ 添加多出口绑定</button>
    </form>
    <span class="muted" style="font-size:12px">选择国家后添加；全部表示不限国家</span>
  </div>
   <div style="display:flex;gap:8px;align-items:center;margin-bottom:10px;flex-wrap:wrap">
     <form action="/add_multi" method="get" style="display:inline-flex;gap:4px;align-items:center">
       <select name="country" class="select" style="height:30px;min-width:90px;font-size:12px">{country_opts}</select>
       <button class="btn btn-sm btn-green" type="submit">＋ 添加多出口绑定</button>
     </form>
     <span class="muted" style="font-size:12px">选择国家后添加；全部表示不限国家</span>
   </div>
   <div class="table-wrap">
    <table>
      <thead><tr><th>状态</th><th>本地端口</th><th colspan="2">上游代理</th><th>操作</th></tr></thead>
      <tbody>{multi_rows}</tbody>
    </table>
  </div>
   <div class="section-title">\U0001f4e1 订阅源（daily_free_vpn 等）</div>
   <div class="table-wrap">
     <table>
       <thead><tr><th>名称</th><th>订阅链接（可直接导入 Clash / V2Ray / Sing-box）</th></tr></thead>
       <tbody>{sub_rows}</tbody>
     </table>
   </div>
</main>
</body>
</html>"""
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()
        self.wfile.write(html.encode())
        return

    def do_POST(self):
        if self.path != "/login":
            self.send_error(404)
            return
        if not CONFIG["auth_user"]:
            self._login_page(error="未配置 auth_user/auth_pass，Web 面板已禁用")
            return
        try:
            length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(length).decode("utf-8", errors="ignore")
            qs = parse_qs(body)
            u = (qs.get("user") or [""])[0]
            p = (qs.get("pass") or [""])[0]
        except Exception:
            u = p = ""
        if u == CONFIG["auth_user"] and p == CONFIG["auth_pass"]:
            self.send_response(302)
            self.send_header("Set-Cookie", f"pp_session={web_session_token()}; Path=/; HttpOnly")
            self.send_header("Location", "/")
            self.end_headers()
        else:
            self._login_page(error="账号或密码错误")

    def _login_page(self, error=""):
        err_html = f'<div style="color:#f43f5e;margin-bottom:12px">{error}</div>' if error else ""
        html = f"""<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"/><title>登录 - Proxy Pool</title>
<style>body{{font-family:Outfit,system-ui,sans-serif;background:#0a0e17;color:#e8edf7;display:flex;align-items:center;justify-content:center;height:100vh;margin:0}}
.card{{background:rgba(18,24,40,.75);border:1px solid rgba(255,255,255,.07);border-radius:16px;padding:32px;width:320px}}
h2{{margin:0 0 20px;font-size:20px}}
input{{width:100%;height:40px;padding:0 12px;border-radius:10px;border:1px solid rgba(255,255,255,.07);background:rgba(255,255,255,.04);color:#e8edf7;font-size:14px;margin-bottom:12px;box-sizing:border-box}}
button{{width:100%;height:40px;border:none;border-radius:10px;background:linear-gradient(135deg,#6366f1,#4f46e5);color:#fff;font-size:14px;font-weight:600;cursor:pointer}}
</style></head><body><div class="card"><h2>Proxy Pool 登录</h2>{err_html}
<form method="post" action="/login">
<input name="user" placeholder="用户名" autofocus/>
<input name="pass" type="password" placeholder="密码"/>
<button type="submit">登录</button>
</form></div></body></html>"""
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()
        self.wfile.write(html.encode())

    def _json(self, obj, code: int = 200):
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(obj, ensure_ascii=False).encode())

    def _redirect(self, loc):
        self.send_response(302)
        self.send_header("Location", loc)
        self.end_headers()

    def _metrics(self):
        st = pool.stats()
        lines = [
            f"# HELP proxy_pool_available Available proxies",
            f"# TYPE proxy_pool_available gauge",
            f"proxy_pool_available {st['available']}",
            f"# HELP proxy_pool_total Total proxies",
            f"# TYPE proxy_pool_total gauge",
            f"proxy_pool_total {st['total']}",
            f"# HELP proxy_pool_cooling Cooling proxies",
            f"# TYPE proxy_pool_cooling gauge",
            f"proxy_pool_cooling {st['cooling']}",
            f"# HELP proxy_pool_active_connections Active connections",
            f"# TYPE proxy_pool_active_connections gauge",
            f"proxy_pool_active_connections {st['active_conn']}",
        ]
        self.send_response(200)
        self.send_header("Content-Type", "text/plain; version=0.0.4")
        self.end_headers()
        self.wfile.write("\n".join(lines).encode())

    def _export_clash(self):
        lines = ["proxies:"]
        with pool.lock:
            for port, p in list(pool.multi.items())[:15]:
                name = f"{p.country}-{p.ip}"
                lines += [f"  - name: \"{name}\"", "    type: socks5", "    server: 127.0.0.1", f"    port: {port}"]
        lines += ["", "proxy-groups:", "  - name: PROXY", "    type: select", "    proxies:"]
        with pool.lock:
            for _, p in list(pool.multi.items())[:15]:
                lines.append(f"      - \"{p.country}-{p.ip}\"")
        self.send_response(200)
        self.send_header("Content-Type", "text/yaml")
        self.send_header("Content-Disposition", "attachment; filename=clash.yaml")
        self.end_headers()
        self.wfile.write("\n".join(lines).encode())

    def log_message(self, *args): pass

def create_web_server():
    class T(ThreadingMixIn, HTTPServer):
        daemon_threads = True
        allow_reuse_address = True
    return T((CONFIG["bind_host"], CONFIG["web_port"]), WebHandler)

def serve_web(srv):
    log.info(f"Web   监听 {CONFIG['bind_host']}:{CONFIG['web_port']}")
    srv.serve_forever()

# ====================== 主程序 ======================
def graceful_exit(signum, frame):
    log.info("收到退出信号，准备退出...")
    shutdown_event.set()
    # 不阻塞太久：让进行中的刷新尽快自行终止
    try:
        if refresh_lock.acquire(timeout=2):
            refresh_lock.release()
    except Exception:
        pass
    try:
        save_persisted()
    except Exception as e:
        log.error(f"保存持久化失败: {e}")
    log.info("退出完成")
    sys.exit(0)

def main():
    signal.signal(signal.SIGINT, graceful_exit)
    signal.signal(signal.SIGTERM, graceful_exit)

    log.info("=" * 60)
    log.info("Proxy Pool 最终完整版启动")
    log.info("=" * 60)

    # 单实例锁：避免旧进程尚未完全退出时新进程抢端口，导致部分端口绑定失败
    if not acquire_instance_lock(timeout=15):
        log.error("已有实例在运行（实例锁被占用），本进程退出")
        sys.exit(0)

    # 同步绑定所有核心端口：任一失败则整体退出，交给 systemd 重启/告警
    socks_sock = http_srv = web_srv = None
    try:
        socks_sock = create_socks_socket()
        http_srv = create_http_server()
        web_srv = create_web_server()
    except OSError as e:
        log.error(f"端口绑定失败: {e}（可能有其他进程占用 1080/8080/8888）")
        for obj in (socks_sock, http_srv, web_srv):
            try:
                if obj is not None:
                    obj.close()
            except Exception:
                pass
        sys.exit(1)

    service_status["socks"] = True
    service_status["http"] = True
    service_status["web"] = True

    threading.Thread(target=rate_limit_cleaner, daemon=True).start()
    threading.Thread(target=multi_health_check, daemon=True).start()
    threading.Thread(target=serve_socks, args=(socks_sock,), daemon=True, name="socks").start()
    threading.Thread(target=serve_http, args=(http_srv,), daemon=True, name="http").start()
    threading.Thread(target=serve_web, args=(web_srv,), daemon=True, name="web").start()

    time.sleep(1)
    log.info(f"管理面板已就绪: http://{CONFIG['bind_host']}:{CONFIG['web_port']}")

    # 后台做首次刷新 + 多出口初始化
    def bootstrap():
        try:
            refresh()
            if not shutdown_event.is_set():
                start_multi()
        except Exception as e:
            log.exception(f"初始化刷新失败: {e}")
        def refresher():
            while not shutdown_event.is_set():
                shutdown_event.wait(CONFIG["refresh_interval"])
                if shutdown_event.is_set():
                    break
                try:
                    refresh()
                except Exception as e:
                    log.exception(f"刷新异常: {e}")
        threading.Thread(target=refresher, daemon=True).start()

    threading.Thread(target=bootstrap, daemon=True, name="bootstrap").start()

    while True:
        time.sleep(3600)

if __name__ == "__main__":
    main()
