# Proxy Pool - 生产级免费代理池

多源拉取 · 真实可用性测试 · 本地 HTTP/SOCKS5 · 多出口自动更换 · Web 管理 · 告警 · 限速 · Prometheus

## 功能

- 多源代理拉取（proxifly / syndrid / cmahmud）
- 真实 HTTP 请求测试可用性
- 国家过滤、失败冷却、定时刷新
- 本地 HTTP + SOCKS5 代理（支持账号密码）
- 多出口端口（失效自动更换 + 主动健康检查 + Web 手动更换）
- daily_free_vpn 订阅接入：抽取 http/socks 节点入池，ss/vmess/vless/trojan 节点单独展示
- VPN 节点 Xray 测试、绑定多出口、导出 Xray 客户端配置
- Web 管理面板 + Xray/Clash 导出
- 优质代理持久化
- Telegram/Webhook 告警
- 客户端 IP 限速
- Prometheus `/metrics`
- YAML 配置 + 环境变量

## 快速开始
先让服务起来（文件已在服务器上时）
cd /opt/proxy-pool

# 依赖 + systemd 单元（文件不存在会报错，见下面备选）
./venv/bin/pip install -q -r requirements.txt
cp -f proxy-pool.service /etc/systemd/system/proxy-pool.service
cp -f proxy-pool-healthcheck.sh /usr/local/bin/proxy-pool-healthcheck.sh
chmod +x /usr/local/bin/proxy-pool-healthcheck.sh
cp -f proxy-pool-healthcheck.service proxy-pool-healthcheck.timer /etc/systemd/system/

systemctl daemon-reload
systemctl enable --now proxy-pool
systemctl enable --now proxy-pool-healthcheck.timer
如果 cp 提示某些文件不存在，说明还没上传，先按下面「重新部署」做。

重新部署（推荐，需先上传修复后的 deploy.sh）
把更新后的 deploy.sh 覆盖到 /opt/proxy-pool/deploy.sh，然后：

cd /opt/proxy-pool
sudo bash deploy.sh
新版脚本会：

源/目标同路径时自动跳过（不再中断）；
端口释放最多等 20 秒；
部署 .env、安装 systemd 服务与探活 timer；
启动后调用 /health 验证，并直接打印 JSON。
验证
systemctl status proxy-pool --no-pager
curl -s http://127.0.0.1:8888/health
pgrep -af proxy_pool.py        # 应该只有一个 PID
预期 /health 返回：

{"status":"ok","available":0,"services":{"socks":true,"http":true,"web":true},"multi_ports":[..

Docker 一键部署已就绪。
服务器上一键部署
cd /opt/proxy-pool
chmod +x deploy-docker.sh
sudo bash deploy-docker.sh
脚本结束会打印登录密码，然后访问 http://服务器IP:8888。

常用运维命令
docker compose ps
docker compose logs -f proxy-pool     # 或 tail -f ./data/proxy_pool.log
docker compose restart proxy-pool
docker compose down                   # 停止，./data 数据保留
docker compose up -d --build          # 更新代码后重建
保活机制

### 1. 直接运行

```bash
pip install -r requirements.txt
# 修改 config.yaml 中的密码
python3 proxy_pool.py
```

### 2. Docker 一键部署

```bash
# 首次：自动生成 .env（含随机强密码）、创建 data 目录、构建并启动、探活
sudo bash deploy-docker.sh

# 之后常用命令
docker compose ps
docker compose logs -f
docker compose restart
docker compose down          # 停止（数据保留在 ./data）
```

手动方式：

```bash
cp .env.example .env         # 修改 AUTH_PASS
mkdir -p data
docker compose up -d --build
curl http://127.0.0.1:8888/health
```

说明：

- 容器 `restart: unless-stopped` + Dockerfile 内置 `HEALTHCHECK`，崩溃自动拉起。
- Docker Compose 已配置内存限制 `200M`，适合 256MB VPS。
- **256MB VPS 建议启用 swap**（防止突发 OOM）：
  ```bash
  fallocate -l 1G /swapfile
  chmod 600 /swapfile
  mkswap /swapfile
  swapon /swapfile
  echo '/swapfile none swap sw 0 0' >> /etc/fstab
  ```
- 日志与优质代理持久化在 `./data`（`proxy_pool.log`、`good_proxies.json`）。
- 多出口端口映射 `18081-18200`；VPN 节点绑定会从 `18089` 往后自动分配。
- Linux 上也可改用 `network_mode: host`（动态端口无需映射）。

### 3. systemd

```bash
sudo mkdir -p /opt/proxy-pool
sudo cp proxy_pool.py config.yaml requirements.txt /opt/proxy-pool/
cd /opt/proxy-pool && sudo python3 -m venv venv && sudo ./venv/bin/pip install -r requirements.txt
sudo cp proxy-pool.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now proxy-pool
```

若要使用 Web 页面的「测试可用节点 / 绑定多出口 / 导出 Xray 配置」，还需安装 Xray-core（x86_64 示例）：

```bash
curl -fsSL -o /tmp/xray.zip https://github.com/XTLS/Xray-core/releases/latest/download/Xray-linux-64.zip
sudo unzip -o /tmp/xray.zip xray -d /usr/local/bin
sudo chmod +x /usr/local/bin/xray
rm -f /tmp/xray.zip
```

arm64 VPS 把下载链接换成 `Xray-linux-arm64-v8a.zip`。安装后在 `.env` 设置 `XRAY_PATH=/usr/local/bin/xray`（默认会自动探测）。

## 端口说明

| 端口 | 说明 |
|------|------|
| 8080 | HTTP 代理 |
| 1080 | SOCKS5 代理 |
| 8888 | Web 管理面板 |
| 18081-18088 | 默认多出口（每个端口绑定不同上游） |
| 18089-18200 | Web 动态新增 / VPN 节点绑定的多出口 |

认证账号密码来自 `.env` 的 `AUTH_USER` / `AUTH_PASS`（Docker 一键脚本会生成随机强密码，**务必妥善保存**）。

## Web 面板

访问 `http://IP:8888`

- 查看可用/冷却数量
- 一键刷新
- 多出口手动更换、按国家选择上游
- **VPN 节点面板**：ss / vmess / vless / trojan 节点列表、单节点或批量测试、延迟显示、失败原因
- **VPN 节点绑定多出口**：测试通过后自动启动本地 xray socks 出口，并分配 18089+ 端口
- **导出 Xray 配置**：优先导出测试通过的节点；未测试时导出全部可解析节点；生成带 socks/http 入站 + 节点负载均衡的 JSON
- `/sub/*` 订阅源透传（daily_free_vpn）
- `/nodes` VPN 节点 JSON
- `/metrics` Prometheus 指标、`/health` 健康检查

## 配置优先级

环境变量 > `config.yaml` > 代码默认值

常用环境变量：`AUTH_USER`、`AUTH_PASS`、`COUNTRIES`、`REFRESH_INTERVAL`、`ALERT_WEBHOOK`

## 告警

在 `config.yaml` 中设置 `alert_webhook`，当可用代理数量低于 `alert_threshold` 时触发。

Telegram 示例：
```
https://api.telegram.org/bot<token>/sendMessage?chat_id=<id>
```

## 免责声明

本工具仅用于学习与合法用途。免费公开代理不稳定且不可信，请勿传输敏感数据。
