#!/usr/bin/env bash
# Proxy Pool Docker 一键部署
# 用法: sudo bash deploy-docker.sh
set -euo pipefail
cd "$(dirname "$0")"

WEB_PORT=8888

echo "==> 1. 检查 Docker"
if ! command -v docker >/dev/null 2>&1; then
  echo "!! 未安装 Docker，请先安装：curl -fsSL https://get.docker.com | sh"
  exit 1
fi
if docker compose version >/dev/null 2>&1; then
  DC="docker compose"
elif command -v docker-compose >/dev/null 2>&1; then
  DC="docker-compose"
else
  echo "!! 未找到 docker compose 插件，请安装 docker-compose-plugin"
  exit 1
fi

echo "==> 2. 准备 .env"
if [ ! -f .env ]; then
  cp .env.example .env
  # 随机生成强密码
  PASS=$(head -c 18 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c 24)
  sed -i "s|^AUTH_PASS=.*|AUTH_PASS=${PASS}|" .env
  chmod 600 .env
  echo "!! 已生成 .env，登录密码: ${PASS}"
fi
chmod 600 .env

echo "==> 3. 准备数据目录"
mkdir -p data
# 若历史版本把 good_proxies.json 映射成了目录，这里兜底修正
if [ -d good_proxies.json ]; then rmdir good_proxies.json 2>/dev/null || true; fi

echo "==> 4. 构建并启动"
$DC down --remove-orphans 2>/dev/null || true
$DC up -d --build

echo "==> 5. 等待就绪"
ok=0
for _ in $(seq 1 30); do
  if curl -fsS --max-time 3 "http://127.0.0.1:${WEB_PORT}/health" >/dev/null 2>&1; then ok=1; break; fi
  sleep 2
done

if [ "$ok" = "1" ]; then
  echo "✅ 部署成功: http://127.0.0.1:${WEB_PORT}"
  curl -s "http://127.0.0.1:${WEB_PORT}/health"; echo
else
  echo "❌ 探活失败，最近日志："
  $DC logs --tail=60 proxy-pool || true
  exit 1
fi

echo
echo "账号: $(grep -E '^AUTH_USER=' .env | cut -d= -f2-)"
echo "密码: $(grep -E '^AUTH_PASS=' .env | cut -d= -f2-)"
echo "状态: $DC ps"
echo "日志: $DC logs -f"
