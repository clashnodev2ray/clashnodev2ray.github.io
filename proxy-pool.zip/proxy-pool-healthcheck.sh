#!/usr/bin/env bash
# 兜底保活：systemd 只能拉起“退出的进程”，若进程僵死（端口不响应）则用本脚本重启
# 由 proxy-pool-healthcheck.timer 每 2 分钟调用一次
set -u
SERVICE=proxy-pool
URL=http://127.0.0.1:8888/health

if curl -fsS --max-time 5 "$URL" >/dev/null 2>&1; then
  exit 0
fi

# 连续 2 次失败才重启，避免瞬时抖动
sleep 5
if curl -fsS --max-time 5 "$URL" >/dev/null 2>&1; then
  exit 0
fi

echo "[healthcheck] $(date '+%F %T') 探活失败，重启 $SERVICE"
systemctl restart "$SERVICE"
