#!/usr/bin/env bash
# Proxy Pool 保活部署脚本（在服务器上以 root 执行）
# 用法: sudo bash deploy.sh
set -euo pipefail

APP_DIR=/opt/proxy-pool
SERVICE=proxy-pool
UNIT_DIR=/etc/systemd/system

# 源与目标相同（脚本本身就在 /opt/proxy-pool 里执行）时跳过拷贝
copy_if_needed() {
  local src="$1" dst="$2"
  [ -e "$src" ] || return 0
  mkdir -p "$(dirname "$dst")"
  if [ -e "$dst" ] && [ "$(readlink -f "$src")" = "$(readlink -f "$dst")" ]; then
    echo "   跳过（源与目标相同）: $dst"
    return 0
  fi
  cp -f "$src" "$dst"
}

echo "==> 1. 停止旧的运行方式（nohup / 手动启动）"
systemctl stop "$SERVICE" 2>/dev/null || true
pkill -f "proxy_pool.py" 2>/dev/null || true
sleep 2
# 等端口释放（旧进程优雅退出需要几秒）
for p in 1080 8080 8888; do
  for _ in $(seq 1 20); do
    ss -lnt 2>/dev/null | grep -q ":$p " || break
    sleep 1
  done
  if ss -lnt 2>/dev/null | grep -q ":$p "; then
    echo "!! 端口 $p 仍被占用，请检查: ss -lntp | grep :$p"
    exit 1
  fi
done

echo "==> 2. 部署文件到 $APP_DIR"
mkdir -p "$APP_DIR"
copy_if_needed proxy_pool.py "$APP_DIR/proxy_pool.py"
copy_if_needed config.yaml "$APP_DIR/config.yaml"
copy_if_needed requirements.txt "$APP_DIR/requirements.txt"

# 若使用 venv 则安装依赖
if [ -x "$APP_DIR/venv/bin/pip" ] && [ -f "$APP_DIR/requirements.txt" ]; then
  "$APP_DIR/venv/bin/pip" install -q -r "$APP_DIR/requirements.txt" || true
fi

# 部署 .env（包含在发行包里则覆盖；否则保留服务器上已有的）
if [ -f .env ] && [ "$(readlink -f .env)" != "$(readlink -f "$APP_DIR/.env" 2>/dev/null || echo '')" ]; then
  cp -f .env "$APP_DIR/.env"
  echo "==> 已应用随包提供的 .env"
elif [ ! -f "$APP_DIR/.env" ]; then
  cat > "$APP_DIR/.env" <<EOF
AUTH_USER=admin
AUTH_PASS=proxy123
BIND_HOST=0.0.0.0
EOF
  echo "!! 未找到 .env，已生成默认配置，请立即修改 AUTH_PASS"
fi
chmod 600 "$APP_DIR/.env"

echo "==> 3. 安装 systemd unit（崩溃自动拉起 + 僵死探活）"
copy_if_needed proxy-pool.service "$UNIT_DIR/proxy-pool.service"
copy_if_needed proxy-pool-healthcheck.sh /usr/local/bin/proxy-pool-healthcheck.sh
chmod +x /usr/local/bin/proxy-pool-healthcheck.sh
copy_if_needed proxy-pool-healthcheck.service "$UNIT_DIR/proxy-pool-healthcheck.service"
copy_if_needed proxy-pool-healthcheck.timer "$UNIT_DIR/proxy-pool-healthcheck.timer"

systemctl daemon-reload
systemctl enable "$SERVICE" >/dev/null
systemctl enable --now proxy-pool-healthcheck.timer >/dev/null
systemctl restart "$SERVICE"

echo "==> 4. 等待启动"
sleep 8
systemctl --no-pager --full status "$SERVICE" | head -20 || true

echo "==> 5. 探活检查"
ok=0
for _ in $(seq 1 10); do
  if curl -fsS --max-time 3 "http://127.0.0.1:8888/health" >/dev/null 2>&1; then ok=1; break; fi
  sleep 2
done
if [ "$ok" = "1" ]; then
  echo "✅ Web 面板正常: http://127.0.0.1:8888/health"
  curl -s --max-time 3 "http://127.0.0.1:8888/health"
  echo
else
  echo "❌ 探活失败，最近日志："
  journalctl -u "$SERVICE" -n 40 --no-pager || true
  exit 1
fi

echo
echo "查看状态: systemctl status $SERVICE"
echo "查看日志: journalctl -u $SERVICE -f   或  tail -f $APP_DIR/proxy_pool.log"
